import CGMaya_service


service = CGMaya_service.CGService()

print(service.login('zy', 'zy1234', 'newsight'))